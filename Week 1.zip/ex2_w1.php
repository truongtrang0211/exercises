<html> 
<header>
<p> Giải phương trình bậc 2 ax^2+bx+c=0 </p>
<body>
<?php
$a = $_GET ['a'];
$b = $_GET ['b'];
$c = $_GET ['c'];
if ($a == 0) {
	if ($b == 0 && $c==0) 
		{ echo "Phương trình có vô số nghiệm";
    }
	elseif ($b ==0 && $c <>0)
		{ echo "Phương trình vô nghiệm";
    }

    else  { $nghiem = -($c)/$b ;
	echo "Nghiệm phương trình là: $nghiem";
    }
}
else { 
	$delta = $b*$b - (4*$a*$c) 
     if ($delta < 0) {
     	echo "Phương trình vô nghiệm";
     }  
     elseif ($delta == 0) {
     	$nghiem = -($b)/(2*$a);
     	echo "Phương trình có 2 nghiệm kép: $nghiem"; 
     }
     else {
     	$nghiem1 = (-($b)-sqrt($delta)/ (2*a));
     	$nghiem2 = (-($b)+sqrt($delta)/ (2*a));
     echo "Phương trình có 2 nghiệm: $nghiem1 và $nghiem2 " ;
     }
?>

</body>
</header>
</html>
