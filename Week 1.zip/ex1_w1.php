<html> 
<header>
<body>
<?php
$a = $_GET ['a'];
$b = $_GET ['b'];
if ($a == 0) {
	if ($b == 0) 
		{ echo "Phương trình có vô số nghiệm";
	}
	else 
		{ echo "Phương trình vô nghiệm";
}
} 
else { $nghiem = -($b)/$a ;
	echo "Nghiệm phương trình là ". $nghiem;
}
?>

</body>
</header>
</html>
